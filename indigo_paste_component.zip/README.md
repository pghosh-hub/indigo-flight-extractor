
IndiGo Flight Extractor (Paste-enabled)
======================================

This package contains a Streamlit app (app.py) that extracts flights from IndiGo screenshots
and exports to Excel. It supports a paste-from-clipboard component if that component is installed.
However the component's frontend must be built (Node.js) or prebuilt artifacts must be included.

Files:
- app.py
- requirements.txt
- packages.txt
- component/README.md

Deploy:
1. Create a public GitHub repo and upload these files.
2. Deploy on Streamlit Cloud: repository: <yourusername>/<repo>, branch: main, main file path: app.py
3. The app will run with file uploads. To enable Ctrl+V paste, include the built component assets or ask me to supply the prebuilt ZIP.
