
streamlit_clip_paste component (paste-from-clipboard)
====================================================

This folder contains source for a tiny Streamlit Component that captures clipboard images (Ctrl+V)
in the browser and returns base64 image strings to Python.

Note: building the component requires Node.js/npm to compile the frontend.
Streamlit Cloud does not run npm build steps automatically for custom components, so you have two options:
1) Build locally (npm install && npm run build) and commit the built assets to the repo.
2) Ask me to provide a prebuilt compiled package — I can produce a ZIP with compiled frontend files.

If you want the prebuilt package (no Node on your side), reply and I'll prepare it.
